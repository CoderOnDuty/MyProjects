from django.db import models

# Create your models here.

class Resume(models.Model):

    name = models.CharField(max_length=40)
    age = models.IntegerField()
    email = models.CharField(max_length=50)
    phone = models.IntegerField()
    gender = models.CharField(max_length=10)
    address = models.TextField()
    dob = models.DateField()
    skills = models.CharField(max_length=100)
    projectsundertaken = models.TextField()
    internship = models.CharField(max_length=300, default="if Yes,where?, if No,please write - Nil")
    schoolname = models.CharField(max_length=50, default="write your schoolname here")
    schoolqualification = models.CharField(max_length=50)
    collegename = models.CharField(max_length=50, default="write your collegename here")
    collegequalification = models.CharField(max_length=50)
    universityname = models.CharField(max_length=50, default="write your university here")
    graduatequalification = models.CharField(max_length=50)
    hobbies = models.CharField(max_length=300, default="example: swimming, gaming, etc")
    languagesknown = models.CharField(max_length=100)
    nationality = models.CharField(max_length=30)
    certification = models.TextField()
    state = models.CharField(max_length=100)
    maritalstatus = models.CharField(max_length=40)
    summary = models.TextField()
