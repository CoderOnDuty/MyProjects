from django.shortcuts import render, redirect
from app.models import Resume
from easy_pdf.views import PDFTemplateResponseMixin
from django.views.generic import DetailView
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm


# Create your views here.

def signup(request):
    form = UserCreationForm()
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid:
            form.save()
    context ={
        'form' : form
    }
    return render(request,"signup.html",context)


def logout(request):
    return render(request,"logout.html")


def home(request):
    resume = Resume.objects.all()
    context ={
        "resume" : resume
    }
    return render(request,"home.html",context)


@login_required
def view(request, id):
    resumedetail = Resume.objects.get(id=id)
    context={
        "resumedetail":resumedetail
    }
    return render(request,"view.html",context)


@login_required
def deleteOneData(request, id):
    delete_resume = Resume.objects.get(id=id)
    delete_resume.delete()
    return redirect("/home")



class PDFUserDetailView(PDFTemplateResponseMixin,DetailView):
    model = Resume
    template_name = "resume_detail.html"


@login_required
def createResume(request):
    if request.method == "POST":
        myname = request.POST.get('name')
        myage = request.POST.get('age')
        myemail = request.POST.get('email')
        myphone = request.POST.get('phone')
        mygender = request.POST.get('gender')
        myaddress = request.POST.get('address')
        mydob = request.POST.get('dob')
        myskills = request.POST.get('skills')
        myprojectsundertaken = request.POST.get('projectsundertaken')
        myinternship = request.POST.get('internship')
        myschoolname = request.POST.get('schoolname')
        myschoolqualification = request.POST.get('schoolqualification')
        mycollegename = request.POST.get('collegename')
        mycollegequalification = request.POST.get('collegequalification')
        myuniversityname = request.POST.get('universityname')
        mygraduatequalification = request.POST.get('graduatequalification')
        myhobbies = request.POST.get('hobbies')
        mylanguages = request.POST.get('languages')
        mynationality = request.POST.get('nationality')
        mycertification = request.POST.get('certification')
        mystate = request.POST.get('state')
        mymarital = request.POST.get('maritalstatus')
        mysummary = request.POST.get('summary')

        r = Resume(name=myname, age=myage, email=myemail, gender=mygender, phone=myphone, 
                   address=myaddress, dob=mydob, skills=myskills, projectsundertaken=myprojectsundertaken, 
                   internship=myinternship, schoolname=myschoolname, schoolqualification=myschoolqualification, 
                   collegename=mycollegename, collegequalification=mycollegequalification, 
                   universityname=myuniversityname, graduatequalification=mygraduatequalification,hobbies=myhobbies, 
                   languagesknown=mylanguages, nationality=mynationality, certification=mycertification, 
                   state=mystate, maritalstatus=mymarital, summary=mysummary)
        r.save()
        return redirect("/home")

    return render(request, "create_resume.html")

